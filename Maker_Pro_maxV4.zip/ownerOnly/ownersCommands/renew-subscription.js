const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Database } = require('st.db');
const db = new Database('/database/settings');
const tier1subscriptions = new Database('/database/makers/tier1/subscriptions');
const tier2subscriptions = new Database('/database/makers/tier2/subscriptions');
const tier3subscriptions = new Database('/database/makers/tier3/subscriptions');
const { clientId, owner } = require('../../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('renew-subscription')
        .setDescription('تجديد اشتراك')
        .addStringOption(option =>
            option
                .setName('type')
                .setDescription('نوع الاشتراك')
                .setRequired(true)
                .addChoices(
                    { name: 'GOLD', value: 'tier2' },
                    { name: 'Diamond', value: 'tier3' }
                )
        )
        .addStringOption(option =>
            option
                .setName('serverid')
                .setDescription('ايدي السيرفر')
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option
                .setName('days')
                .setDescription('عدد الأيام')
                .setRequired(true)
        ),
    async execute(interaction) {
        if (!owner.includes(interaction.user.id)) return;

        const type = interaction.options.getString('type');
        const serverid = interaction.options.getString('serverid');
        const days = interaction.options.getInteger('days');
        
        let subsearch = [];
        if (type === 'tier1') {
            subsearch = tier1subscriptions.get('tier1_subs') || [];
        } else if (type === 'tier2') {
            subsearch = tier2subscriptions.get('tier2_subs') || [];
        } else if (type === 'tier3') {
            subsearch = tier3subscriptions.get('tier3_subs') || [];
        }

        const serversearch = subsearch.find(su => su.guildid === serverid);
        if (!serversearch) {
            return interaction.reply({ content: '**لم يتم العثور على اشتراك بهذا الايدي**' });
        }

        const daysInSeconds = days * 24 * 60 * 60;
        let { timeleft } = serversearch;
        timeleft += daysInSeconds;
        serversearch.timeleft = timeleft;

        if (type === 'tier1') {
            await tier1subscriptions.set('tier1_subs', subsearch);
        } else if (type === 'tier2') {
            await tier2subscriptions.set('tier2_subs', subsearch);
        } else if (type === 'tier3') {
            await tier3subscriptions.set('tier3_subs', subsearch);
        }

        const remainingDays = Math.floor(timeleft / (24 * 60 * 60));

        const doneembed = new EmbedBuilder()
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL({ dynamic: true }) })
            .setTimestamp()
            .setColor('#000000')
            .setTitle('**تم تجديد الاشتراك واضافة الوقت بنجاح**')
            .setDescription(`**عدد الأيام المتبقية الآن: \`${remainingDays}\`**`);

        return interaction.reply({ embeds: [doneembed] });
    }
};
