const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { Database } = require("st.db");

const usersdata = new Database(`/database/usersdata/usersdata`);

module.exports = {
    ownersOnly: true,
    data: new SlashCommandBuilder()
        .setName('give-coins')
        .setDescription('Give user coins')
        .addUserOption(option => option
            .setName('user')
            .setDescription('الشخص المراد اعطائه الرصيد')
            .setRequired(true))
        .addIntegerOption(option => option
            .setName('quantity')
            .setDescription('الكمية')
            .setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: false });
        const user = interaction.options.getUser('user');
        const quantity = interaction.options.getInteger('quantity');
        const maxCoins = 300; // تعيين الحد الأقصى لعدد القطع
        let userbalance = usersdata.get(`balance_${user.id}_${interaction.guild.id}`);

        if (userbalance && userbalance >= maxCoins) {
            // يتم رفض الطلب إذا كان الرصيد يساوي أو يتجاوز الحد الأقصى
            const maxBalanceEmbed = new EmbedBuilder()
                .setDescription(`**${user} لديه بالفعل الحد الأقصى من الرصيد (${maxCoins} قطعة). لا يمكن إعطاؤه المزيد.**`)
                .setColor('#f6f6f6')
                .setTimestamp();

            return interaction.editReply({ embeds: [maxBalanceEmbed] });
        } else {
            // إذا كان الرصيد أقل من الحد الأقصى، يتم إضافة الكمية المحددة
            let newuserbalance = userbalance ? Math.min(maxCoins, userbalance + quantity) : quantity;
            await usersdata.set(`balance_${user.id}_${interaction.guild.id}`, newuserbalance);

            // إرسال رسالة التأكيد
            const balanceEmbed = new EmbedBuilder()
                .setDescription(`**تم اعطاء ${user} الرصيد بنجاح\nرصيده الحالي هو : \`${newuserbalance}\`**`)
                .setColor('#f6f6f6')
                .setTimestamp();

            return interaction.editReply({ embeds: [balanceEmbed] });
        }
    }
};