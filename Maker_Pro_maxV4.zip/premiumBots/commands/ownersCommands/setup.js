const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle } = require("discord.js");
const { Database } = require("st.db")
const setting = new Database("/database/settingsdata/setting")
const statuses = new Database("/database/settingsdata/statuses")
const prices = new Database("/database/settingsdata/prices.json")
const tokens = new Database("tokens/tokens")
const process = require('process'); 

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('تسطيب النظام')
    .addUserOption(Option => Option
        .setName(`recipient`)
        .setDescription(`مستلم الارباح`)
        .setRequired(false))
                      .addChannelOption(Option => Option
                .setName(`dashboard`)
                .setDescription(`روم داشبورد`)
                .setRequired(false))
            .addChannelOption(Option => Option
                .setName(`logroom`)
                .setDescription(`روم لوج شراء البوتات`)
                .setRequired(false))
                .addChannelOption(Option => Option
                    .setName(`buybotroom`)
                    .setDescription(`روم بانل شراء البوتات`)
                    .setRequired(false))
                .addRoleOption(Option => Option
                    .setName(`clientrole`)
                    .setDescription(`رول العملاء`)
                    .setRequired(false))
                .addUserOption(Option => Option
                    .setName(`probot`)
                    .setDescription(`البروبوت`)
                    .setRequired(false))
                    .addStringOption(text => text
                        .setName(`bot-message`)
                        .setDescription(`رسالة بانل البوتات`)
                        .setRequired(false))
                     .addStringOption(text => text
                        .setName(`dashboard-message`)
                        .setDescription(`رسالة بانل الداش بورد`)
                        .setRequired(false))
        , // or false
async execute(interaction) {
    await interaction.deferReply({ephemeral:true})
   let recipient = interaction.options.getUser(`recipient`)
   let logroom = interaction.options.getChannel(`logroom`)
   let dashboard = interaction.options.getChannel(`dashboard`)
   let buybotroom = interaction.options.getChannel(`buybotroom`)
   let clientrole = interaction.options.getRole(`clientrole`)
   let probot = interaction.options.getUser(`probot`)
   let line = interaction.options.getAttachment(`line`)
   let botmessage = interaction.options.getString(`bot-message`)
   let dashboardmessage = interaction.options.getString(`dashboard-message`)
   if(recipient) {
   await setting.set(`recipient_${interaction.guild.id}` , recipient.id)
   }
   if(dashboard) {
    await setting.set(`dashboard_room_${interaction.guild.id}` , dashboard.id)
     
   }
   if(logroom) {
    await setting.set(`log_room_${interaction.guild.id}` , logroom.id)
   }
   if(clientrole) {
    await setting.set(`client_role_${interaction.guild.id}` , clientrole.id)
   }
   if(probot) {
    await setting.set(`probot_${interaction.guild.id}` , probot.id)
}
if(buybotroom) {
    await setting.set(`buy_bot_room${interaction.guild.id}` , buybotroom.id)
   }
   if (botmessage) {
    await setting.set(`message_${interaction.guild.id}`, botmessage)
}
if (dashboardmessage) {
await setting.set(`message3_${interaction.guild.id}`, dashboardmessage)
}
   if(line) {
    await setting.set(`line_${interaction.guild.id}` , line.url)
   }
   
   if(!recipient && !line && !logroom && !clientrole && !probot && !buybotroom &&!botmessage &&  !dashboard && !dashboardmessage) return interaction.editReply({content:`**الرجاء تحديد اعداد واحد على الاقل**`}) 
   return interaction.editReply({content:`**تم تحديد الاعدادات بنجاح**`})
}
}