const { SlashCommandBuilder, EmbedBuilder , PermissionsBitField, ActionRowBuilder,ButtonBuilder,MessageComponentCollector,ButtonStyle, Embed, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require("discord.js");
const { Database } = require("st.db")
const db = new Database("/database/data")
const setting = new Database("/database/settingsdata/setting")
const image = new Database("/database/settingsdata/image")

module.exports = {
    ownersOnly:true,
    data: new SlashCommandBuilder()
    .setName('send-dashboard')
    .setDescription(`Send dashboard panel`),
async execute(interaction) {
    await interaction.deferReply({ephemeral:true})
    let dashboard = await setting.get(`dashboard_room_${interaction.guild.id}`)
    let message5 = await setting.get(`message3_${interaction.guild.id}`)
    let image5 = await image.get(`image3_${interaction.guild.id}`)
    if(!dashboard && !message5 && !image5) return interaction.editReply({content:`**لم يتم تحديد الاعدادات**`})
    let theroom = interaction.guild.channels.cache.find(ch => ch.id == dashboard)
    let embed = new EmbedBuilder()
    .setTitle(`**Maker Simple Dashboard**`)
    .setDescription(`${message5}`)
    .setThumbnail(interaction.guild.iconURL())
    .setColor('#6586DB')
    .setImage(`${image5}`)
    .setTimestamp();

   const select = new StringSelectMenuBuilder()
    .setCustomId('select_bot')
    .setPlaceholder('Make a selection')
    .addOptions(
            new StringSelectMenuOptionBuilder()
            .setLabel('Set status')
            .setDescription('تعين حالة البوت')
            .setValue('changeActive'),
        new StringSelectMenuOptionBuilder()
            .setLabel('اﻋـادۃ ۛتــعــيــيــن')
            .setDescription('̨ﻋــمــل اﻋـادۃ ۛتــعــيــيــن لــلاخــتــيـار')
.setEmoji('🔧')
            .setValue('Reset_Selected'),
        
    );

     const row = new ActionRowBuilder()
    .addComponents(select);



   

    
   

        const free = new ButtonBuilder()
            .setCustomId(`ownerch`)
            .setLabel('change owner')
            .setStyle(ButtonStyle.Success);

    

const free3 = new ButtonBuilder()
    .setCustomId(`showMyBots`)
    .setLabel('Show my info')
    
    .setStyle(ButtonStyle.Primary);
  
 const usecode = new ButtonBuilder()
            .setCustomId('usecode')
            .setLabel('Redeem')

            .setStyle(ButtonStyle.Danger);
const row2 = new ActionRowBuilder()
    .addComponents(free , free3, usecode);



    theroom.send({embeds: [embed], components:[row, row2]})
return interaction.editReply({ content: `**تم ارسال الرسالة بنجاح**` })
}
}